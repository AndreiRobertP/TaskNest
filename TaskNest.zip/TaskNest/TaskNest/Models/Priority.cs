﻿using System;

namespace TaskNest.Models
{
    [Serializable]
    public enum EPriority
    {
        Low,
        Medium,
        High,
        Critical
    }
}
